var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvwxy~",
  1: "cefgnruv",
  2: "cefgmnruv",
  3: "abcdefgilmnoprstuv~",
  4: "abcdfhimnprstuvwxy",
  5: "gv",
  6: "bcdglmoprtwy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Friends",
  6: "Macros"
};

