var searchData=
[
  ['unweightedshortestpath',['unweightedShortestPath',['../class_graph.html#ab7d09dfde91ef847f5b1d8560948fe09',1,'Graph']]],
  ['urgencies',['Urgencies',['../class_urgencies.html#a6f46b51f656ecb34e94a74d8f7424492',1,'Urgencies::Urgencies()'],['../class_urgencies.html#afc655c41f1caa0ae441a484e7d465646',1,'Urgencies::Urgencies(Graph&lt; Node, Road &gt; *map, vector&lt; Facility &gt; facilities)']]],
  ['utils',['Utils',['../class_utils.html#a452e78692c87ed5c7c993b6c6ac4981a',1,'Utils']]]
];
