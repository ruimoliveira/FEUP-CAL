var searchData=
[
  ['sock',['sock',['../class_connection.html#a50ca7c17a64836ca25a1fe9953cc6cf6',1,'Connection']]],
  ['startid',['startID',['../class_gable.html#a7ecffc4901f9092efb6b3008c70fcdc3',1,'Gable']]]
];
