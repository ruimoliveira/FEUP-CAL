var searchData=
[
  ['node',['Node',['../class_node.html#ad7a34779cad45d997bfd6d3d8043c75f',1,'Node::Node()'],['../class_node.html#a97a79f1f99de6551a23c14eb77ecf754',1,'Node::Node(unsigned long long id, double xDeg, double yDeg, double xRad, double yRad)'],['../class_node.html#aa5915d1258cd2e75c9ae8f8bd3644e7f',1,'Node::Node(unsigned long long id)']]],
  ['nodedistance',['nodeDistance',['../class_utils.html#a05c1a3fb0cf0a8618b7cecee407688ec',1,'Utils']]]
];
