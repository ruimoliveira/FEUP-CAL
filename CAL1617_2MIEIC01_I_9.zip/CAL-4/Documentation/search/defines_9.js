var searchData=
[
  ['tab',['TAB',['../_menu_8h.html#ad58a1fbfc85c7e4790fc55e654f50221',1,'Menu.h']]],
  ['tab_5fbig',['TAB_BIG',['../_menu_8h.html#a31d3ba27878dce28cb992276a8698265',1,'Menu.h']]],
  ['tries',['TRIES',['../_menu_8h.html#a527eb3eaec4a1cb30a1a98470e16d5a5',1,'Menu.h']]]
];
