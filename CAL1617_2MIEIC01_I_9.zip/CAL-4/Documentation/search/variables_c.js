var searchData=
[
  ['twoway',['twoWay',['../class_road.html#ae51b78f2bffa9d38549ba741b057bda7',1,'Road']]],
  ['type',['type',['../class_facility.html#a3050cc02cd7decb1d737efefda0a3799',1,'Facility::type()'],['../class_vehicle.html#a99487b9f05bb36855d7af79df4f60781',1,'Vehicle::type()']]]
];
