Para o programa correr sem problemas � necess�rio adicionar a biblioteca libwsock32.
Para isso � necess�rio ir a Project->Properties->C/C++ Build->Settings->Tool Settings->MinGW C++ Linker->Miscellaneous->Other objects->Add
O path para essa biblioteca estar� em MinGW\lib\libwsock32.a, ou em MinGW.x86\lib\libwsock32.a

Nalguns computadores � necess�rio adicionar uma vari�vel de ambiente em Project->Properties->C/C++ Build->Environment e adicionar/alterar o path para a vari�vel MINGW_HOME para C:\MinGW.x86
Tamb�m nalguns computadores foi necess�rio alterar o compilador em Project->Properties->C/C++ Build->Settings->Tool Settings->GCC C++ Compiler->Dialect->Other Dialect flags para -std=gnu++1y